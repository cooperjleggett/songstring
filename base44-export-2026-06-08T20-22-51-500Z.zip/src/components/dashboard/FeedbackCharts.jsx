import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, RadarChart, Radar, PolarGrid, PolarAngleAxis, Cell } from "recharts";

const BLUE = "hsl(214 89% 52%)";

export default function FeedbackCharts({ tracks, feedbacksGiven }) {
  // Ratings per track (top 6)
  const ratingData = tracks
    .filter(t => t.avg_rating > 0)
    .slice(0, 6)
    .map(t => ({
      name: t.title.length > 14 ? t.title.slice(0, 13) + "…" : t.title,
      rating: t.avg_rating,
    }));

  // Feedback count per track
  const feedbackData = tracks
    .filter(t => t.feedback_count > 0)
    .slice(0, 6)
    .map(t => ({
      name: t.title.length > 14 ? t.title.slice(0, 13) + "…" : t.title,
      reviews: t.feedback_count,
    }));

  // Category breakdown of feedback given
  const categoryMap = {};
  feedbacksGiven.forEach(f => {
    const cat = f.category || "overall";
    categoryMap[cat] = (categoryMap[cat] || 0) + 1;
  });
  const categoryLabels = { production: "Production", lyrics: "Lyrics", vocals: "Vocals", mixing: "Mixing", overall: "Overall" };
  const categoryData = Object.entries(categoryMap).map(([key, val]) => ({
    subject: categoryLabels[key] || key,
    value: val,
  }));

  if (tracks.length === 0) return null;

  return (
    <div className="grid sm:grid-cols-2 gap-4 mb-8">
      {/* Avg ratings chart */}
      {ratingData.length > 0 && (
        <div className="rounded-xl border border-border bg-white p-5">
          <h3 className="font-heading font-semibold text-sm text-foreground mb-4">Average Ratings</h3>
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={ratingData} barSize={24}>
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: "hsl(220 10% 50%)" }} axisLine={false} tickLine={false} />
              <YAxis domain={[0, 5]} ticks={[1, 2, 3, 4, 5]} tick={{ fontSize: 11, fill: "hsl(220 10% 50%)" }} axisLine={false} tickLine={false} width={20} />
              <Tooltip
                contentStyle={{ borderRadius: 8, border: "1px solid hsl(220 14% 90%)", fontSize: 12 }}
                formatter={(v) => [v.toFixed(1), "Rating"]}
              />
              <Bar dataKey="rating" fill={BLUE} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Reviews per track */}
      {feedbackData.length > 0 && (
        <div className="rounded-xl border border-border bg-white p-5">
          <h3 className="font-heading font-semibold text-sm text-foreground mb-4">Reviews Per Track</h3>
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={feedbackData} barSize={24}>
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: "hsl(220 10% 50%)" }} axisLine={false} tickLine={false} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: "hsl(220 10% 50%)" }} axisLine={false} tickLine={false} width={20} />
              <Tooltip
                contentStyle={{ borderRadius: 8, border: "1px solid hsl(220 14% 90%)", fontSize: 12 }}
                formatter={(v) => [v, "Reviews"]}
              />
              <Bar dataKey="reviews" fill={BLUE} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Category radar */}
      {categoryData.length > 1 && (
        <div className="rounded-xl border border-border bg-white p-5 sm:col-span-2">
          <h3 className="font-heading font-semibold text-sm text-foreground mb-4">Feedback You Give — by Category</h3>
          <ResponsiveContainer width="100%" height={180}>
            <RadarChart data={categoryData}>
              <PolarGrid stroke="hsl(220 14% 90%)" />
              <PolarAngleAxis dataKey="subject" tick={{ fontSize: 12, fill: "hsl(220 10% 50%)" }} />
              <Radar dataKey="value" stroke={BLUE} fill={BLUE} fillOpacity={0.15} strokeWidth={2} />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}