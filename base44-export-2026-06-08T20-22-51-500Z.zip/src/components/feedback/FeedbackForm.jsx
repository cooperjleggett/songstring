const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";
import { Star } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

import { useAuth } from "@/lib/AuthContext";
import { useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";

export default function FeedbackForm({ trackId }) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState("");
  const [category, setCategory] = useState("overall");
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (rating === 0 || !comment.trim()) return;

    setSubmitting(true);
    await db.entities.Feedback.create({
      track_id: trackId,
      rating,
      comment: comment.trim(),
      category,
      reviewer_name: user?.full_name || "Anonymous",
    });

    const allFeedback = await db.entities.Feedback.filter({ track_id: trackId });
    const avgRating = allFeedback.reduce((sum, f) => sum + f.rating, 0) / allFeedback.length;
    await db.entities.Track.update(trackId, {
      avg_rating: Math.round(avgRating * 10) / 10,
      feedback_count: allFeedback.length,
    });

    queryClient.invalidateQueries({ queryKey: ["feedback", trackId] });
    queryClient.invalidateQueries({ queryKey: ["track", trackId] });
    setRating(0);
    setComment("");
    setCategory("overall");
    setSubmitting(false);
  };

  return (
    <motion.form
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      onSubmit={handleSubmit}
      className="rounded-2xl border border-border bg-white p-5 space-y-4"
    >
      <h3 className="font-heading font-semibold text-base">Leave Feedback</h3>

      {/* Star Rating */}
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4, 5].map((value) => (
          <button
            key={value}
            type="button"
            onClick={() => setRating(value)}
            onMouseEnter={() => setHoverRating(value)}
            onMouseLeave={() => setHoverRating(0)}
            className="p-0.5 transition-transform hover:scale-110"
          >
            <Star
              className={`w-6 h-6 transition-colors ${
                value <= (hoverRating || rating)
                  ? "text-amber-400 fill-amber-400"
                  : "text-muted-foreground/25"
              }`}
            />
          </button>
        ))}
        <span className="ml-1.5 text-xs text-muted-foreground">
          {rating > 0 ? `${rating}/5` : "Rate this track"}
        </span>
      </div>

      {/* Category */}
      <Select value={category} onValueChange={setCategory}>
        <SelectTrigger className="bg-background border-border text-sm h-9">
          <SelectValue placeholder="Feedback category" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="overall">Overall</SelectItem>
          <SelectItem value="production">Production</SelectItem>
          <SelectItem value="lyrics">Lyrics</SelectItem>
          <SelectItem value="vocals">Vocals</SelectItem>
          <SelectItem value="mixing">Mixing</SelectItem>
        </SelectContent>
      </Select>

      {/* Comment */}
      <Textarea
        value={comment}
        onChange={(e) => setComment(e.target.value)}
        placeholder="Share your thoughts on this track..."
        className="min-h-[90px] bg-background border-border resize-none text-sm"
      />

      <button
        type="submit"
        disabled={submitting || rating === 0 || !comment.trim()}
        className="w-full h-9 rounded-lg btn-primary text-white text-sm font-semibold disabled:opacity-40 disabled:cursor-not-allowed transition-opacity"
      >
        {submitting ? "Submitting..." : "Submit Feedback"}
      </button>
    </motion.form>
  );
}