import { useState } from "react";
import { Star, User, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { format } from "date-fns";

const categoryLabels = {
  production: "Production",
  lyrics: "Lyrics",
  vocals: "Vocals",
  mixing: "Mixing",
  overall: "Overall",
};

export default function FeedbackItem({
  feedback,
  index = 0,
  currentUserId,
  isAdmin,
  onDelete,
}) {
  const [confirmDelete, setConfirmDelete] = useState(false);
  const canDelete = onDelete && (feedback.created_by_id === currentUserId || isAdmin);

  const handleDeleteClick = (e) => {
    e.stopPropagation();
    if (confirmDelete) {
      onDelete(feedback.id);
    } else {
      setConfirmDelete(true);
      setTimeout(() => setConfirmDelete(false), 3000);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      className="rounded-xl border border-border bg-white p-4 space-y-2.5"
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
            <User className="w-4 h-4 text-muted-foreground" />
          </div>
          <div className="min-w-0">
            <p className="font-medium text-sm truncate">
              {feedback.reviewer_name || "Anonymous"}
            </p>
            <p className="text-xs text-muted-foreground">
              {feedback.created_date
                ? format(new Date(feedback.created_date), "MMM d, yyyy")
                : ""}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {feedback.category && (
            <Badge
              variant="outline"
              className="text-xs border-border text-muted-foreground font-normal"
            >
              {categoryLabels[feedback.category] || feedback.category}
            </Badge>
          )}
          <div className="flex items-center gap-0.5">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`w-3 h-3 ${
                  i < feedback.rating
                    ? "text-amber-400 fill-amber-400"
                    : "text-muted-foreground/20"
                }`}
              />
            ))}
          </div>
          {canDelete && (
            <button
              onClick={handleDeleteClick}
              title={confirmDelete ? "Click again to confirm" : "Delete feedback"}
              className={`ml-1 transition-colors ${
                confirmDelete
                  ? "text-destructive"
                  : "text-muted-foreground hover:text-destructive"
              }`}
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      <p className="text-sm text-foreground/80 leading-relaxed">{feedback.comment}</p>

      {confirmDelete && (
        <p className="text-xs text-destructive font-medium">
          Click the trash icon again to confirm deletion.
        </p>
      )}
    </motion.div>
  );
}