const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Loader2, AtSign, Search, User } from "lucide-react";

export default function NewMessageModal({ open, onClose, currentUser, onConversationStart }) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [searched, setSearched] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [messageText, setMessageText] = useState("");
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!query.trim()) return;
    setSearching(true);
    setSearched(false);
    setResults([]);
    setSelectedUser(null);
    setError("");

    try {
      const cleanQuery = query.replace(/^@/, "").toLowerCase().trim();
      const found = await db.entities.User.filter({ username: cleanQuery });
      // Filter out self
      const filtered = found.filter(u => u.id !== currentUser?.id);
      setResults(filtered);
      setSearched(true);
    } catch {
      setError("Search failed. Please try again.");
    } finally {
      setSearching(false);
    }
  };

  const handleSend = async () => {
    if (!selectedUser || !messageText.trim()) return;
    setSending(true);
    setError("");
    try {
      const senderName = currentUser?.username ? `@${currentUser.username}` : (currentUser?.display_name || currentUser?.full_name || currentUser?.email);
      const recipientName = selectedUser.username ? `@${selectedUser.username}` : (selectedUser.display_name || selectedUser.full_name || "User");
      await db.entities.Message.create({
        sender_id: currentUser.id,
        recipient_id: selectedUser.id,
        sender_name: senderName,
        recipient_name: recipientName,
        content: messageText.trim(),
        read: false,
      });
      onConversationStart({ userId: selectedUser.id, name: recipientName });
      onClose();
    } catch (err) {
      setError(err.message || "Failed to send message.");
      setSending(false);
    }
  };

  const handleClose = () => {
    setQuery("");
    setResults([]);
    setSearched(false);
    setSelectedUser(null);
    setMessageText("");
    setError("");
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>New Message</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 pt-2">
          {!selectedUser ? (
            <>
              <form onSubmit={handleSearch} className="flex gap-2">
                <div className="relative flex-1">
                  <AtSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Search by username…"
                    value={query}
                    onChange={e => setQuery(e.target.value)}
                    className="pl-9"
                    autoFocus
                  />
                </div>
                <Button type="submit" disabled={searching || !query.trim()} size="default">
                  {searching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                </Button>
              </form>

              {error && (
                <p className="text-sm text-destructive">{error}</p>
              )}

              {searched && results.length === 0 && (
                <div className="text-center py-6 text-muted-foreground text-sm">
                  No user found with that username.
                </div>
              )}

              {results.length > 0 && (
                <div className="space-y-1">
                  {results.map(u => (
                    <button
                      key={u.id}
                      onClick={() => setSelectedUser(u)}
                      className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-accent transition-colors text-left"
                    >
                      <div className="w-9 h-9 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 overflow-hidden">
                        {u.avatar_url ? (
                          <img src={u.avatar_url} alt={u.username} className="w-full h-full object-cover" />
                        ) : (
                          <User className="w-4 h-4 text-primary" />
                        )}
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-foreground">@{u.username}</p>
                        {u.display_name && u.display_name !== u.username && (
                          <p className="text-xs text-muted-foreground">{u.display_name}</p>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </>
          ) : (
            <>
              <div className="flex items-center gap-3 p-3 rounded-lg bg-accent">
                <div className="w-9 h-9 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 overflow-hidden">
                  {selectedUser.avatar_url ? (
                    <img src={selectedUser.avatar_url} alt={selectedUser.username} className="w-full h-full object-cover" />
                  ) : (
                    <User className="w-4 h-4 text-primary" />
                  )}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-foreground">@{selectedUser.username}</p>
                  {selectedUser.display_name && selectedUser.display_name !== selectedUser.username && (
                    <p className="text-xs text-muted-foreground">{selectedUser.display_name}</p>
                  )}
                </div>
                <button onClick={() => setSelectedUser(null)} className="text-xs text-muted-foreground hover:text-foreground">
                  Change
                </button>
              </div>

              <textarea
                value={messageText}
                onChange={e => setMessageText(e.target.value)}
                placeholder="Write your message…"
                className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm resize-none h-28 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                autoFocus
              />

              {error && <p className="text-sm text-destructive">{error}</p>}

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={handleClose}>Cancel</Button>
                <Button onClick={handleSend} disabled={sending || !messageText.trim()}>
                  {sending ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : null}
                  Send Message
                </Button>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}