const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

export default function SongstringLogo({ size = 40, className = "" }) {
  return (
    <img
      src="https://media.db.com/images/public/6a1f2d5bbe0ec39038b9660e/dc1125ec6_generated_image.png"
      alt="Songstring"
      width={size}
      height={size}
      className={`object-contain ${className}`}
      style={{ width: size, height: size }}
    />
  );
}