import { Link, useLocation } from "react-router-dom";
import { Upload, Home, User, LogOut, Menu, X, MessageSquare, Search } from "lucide-react";
import { Button } from "@/components/ui/button";

import { useAuth } from "@/lib/AuthContext";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import SongstringLogo from "@/components/SongstringLogo";

export default function Navbar() {
  const location = useLocation();
  const { user } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  const links = [
    { path: "/", label: "Discover", icon: Home },
    { path: "/search", label: "Search", icon: Search },
    { path: "/upload", label: "Upload", icon: Upload },
    { path: "/dashboard", label: "Dashboard", icon: User },
    { path: "/messages", label: "Messages", icon: MessageSquare },
  ];

  const isActive = (path) => location.pathname === path;

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border bg-white/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-2.5 group">
            <SongstringLogo size={38} className="group-hover:opacity-90 transition-opacity" />
            <span className="text-xl font-heading font-bold tracking-tight text-foreground">
              Song<span className="text-primary">string</span>
            </span>
          </Link>

          {/* Desktop nav */}