import { motion } from "framer-motion";
import { Music, MessageSquare, Star, Play, Pause, Share2, Check } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { useState, useRef } from "react";

const genreLabels = {
  hip_hop: "Hip Hop", rnb: "R&B", pop: "Pop", rock: "Rock",
  electronic: "Electronic", jazz: "Jazz", country: "Country",
  latin: "Latin", indie: "Indie", other: "Other"
};

export default function TrackCard({ track, index = 0 }) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [copied, setCopied] = useState(false);
  const audioRef = useRef(null);
  const navigate = useNavigate();

  const handleShare = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const url = `${window.location.origin}/track?id=${track.id}`;
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const togglePlay = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.04, duration: 0.3 }}
    >
      <Link to={`/track?id=${track.id}`}>
        <div className="group relative rounded-2xl border border-border bg-white overflow-hidden hover:shadow-md transition-all duration-200">
          {/* Cover */}
          <div className="relative aspect-square bg-muted flex items-center justify-center overflow-hidden">
            {track.cover_url ? (
              <img src={track.cover_url} alt={track.title} className="w-full h-full object-cover" />
            ) : (
              <div className="flex flex-col items-center gap-2">
                <Music className="w-9 h-9 text-muted-foreground/40" />
              </div>
            )}

            {/* Play button overlay */}
            <button
              onClick={togglePlay}
              className="absolute inset-0 flex items-center justify-center bg-black/0 group-hover:bg-black/25 transition-all duration-200"
            >
              <div className="w-11 h-11 rounded-full btn-primary flex items-center justify-center opacity-0 group-hover:opacity-100 scale-90 group-hover:scale-100 transition-all duration-200 shadow-md">
                {isPlaying ? (
                  <Pause className="w-4 h-4 text-white" />
                ) : (
                  <Play className="w-4 h-4 text-white ml-0.5" />
                )}
              </div>
            </button>

            {track.genre && (
              <span className="absolute top-2.5 left-2.5 text-xs font-medium px-2 py-0.5 rounded-full bg-white/90 text-foreground border border-border/60">
                {genreLabels[track.genre] || track.genre}
              </span>
            )}
          </div>

          {/* Info */}
          <div className="p-3.5 space-y-1">
            <h3 className="font-heading font-semibold text-sm text-foreground truncate">
              {track.title}
            </h3>
            <button
              onClick={(e) => { e.preventDefault(); if (track.created_by_id) navigate(`/profile?id=${track.created_by_id}`); }}
              className="text-xs text-muted-foreground truncate hover:text-primary transition-colors text-left w-full"
            >
              {track.artist_name}
            </button>
            <div className="flex items-center justify-between pt-1">
              <div className="flex items-center gap-1">
                <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                <span className="text-xs font-medium text-foreground">
                  {track.avg_rating ? track.avg_rating.toFixed(1) : "—"}
                </span>
              </div>
              <div className="flex items-center gap-1 text-muted-foreground">
                <MessageSquare className="w-3 h-3" />
                <span className="text-xs">{track.feedback_count || 0}</span>
              </div>
              <button
                onClick={handleShare}
                className="ml-auto text-muted-foreground hover:text-primary transition-colors"
                title="Copy link"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Share2 className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          <audio
            ref={audioRef}
            src={track.audio_url}
            onEnded={() => setIsPlaying(false)}
          />
        </div>
      </Link>
    </motion.div>
  );
}