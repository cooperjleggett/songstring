import { useRef } from "react";
import { motion, useMotionValue, useTransform, useAnimation } from "framer-motion";
import { Music, Star, MessageSquare, X, MessageCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";

const genreLabels = {
  hip_hop: "Hip Hop", rnb: "R&B", pop: "Pop", rock: "Rock",
  electronic: "Electronic", jazz: "Jazz", country: "Country",
  latin: "Latin", indie: "Indie", other: "Other",
};

export default function SwipeCard({ track, onSkip, onReview }) {
  const navigate = useNavigate();
  const lastDragEndRef = useRef(0);
  const dragDistRef = useRef(0);
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-280, 0, 280], [-12, 0, 12]);
  const skipOpacity = useTransform(x, [30, 120], [0, 1]);
  const reviewOpacity = useTransform(x, [-120, -30], [1, 0]);
  const controls = useAnimation();

  const flySkip = async () => {
    await controls.start({ x: 700, opacity: 0, transition: { duration: 0.3, ease: "easeIn" } });
    onSkip();
  };

  const flyReview = async () => {
    await controls.start({ x: -700, opacity: 0, transition: { duration: 0.3, ease: "easeIn" } });
    onReview();
  };

  const handleDrag = (_, info) => {
    dragDistRef.current = Math.abs(info.offset.x);
  };

  const handleDragEnd = (_, info) => {
    lastDragEndRef.current = Date.now();
    if (info.offset.x > 100) {
      flySkip();
    } else if (info.offset.x < -100) {
      flyReview();
    } else {
      controls.start({
        x: 0,
        rotate: 0,
        transition: { type: "spring", stiffness: 400, damping: 28 },
      });
    }
  };

  const handleCoverClick = (e) => {
    if (Date.now() - lastDragEndRef.current < 150) return;
    if (dragDistRef.current > 10) {
      dragDistRef.current = 0;
      return;
    }
    const rect = e.currentTarget.getBoundingClientRect();
    const relX = e.clientX - rect.left;
    if (relX < rect.width / 2) {
      flySkip();
    } else {
      flyReview();
    }
  };

  return (
    <motion.div
      style={{ x, rotate, zIndex: 10 }}
      drag="x"
      dragConstraints={{ left: 0, right: 0 }}
      dragElastic={0.6}
      onDrag={handleDrag}
      onDragEnd={handleDragEnd}
      animate={controls}
      className="absolute inset-0 cursor-grab active:cursor-grabbing"
    >
      <div className="w-full h-full rounded-3xl overflow-hidden border border-border/60 bg-white shadow-2xl select-none flex flex-col">

        {/* Cover Art */}
        <div
          className="relative flex-1 overflow-hidden"
          onClick={handleCoverClick}
          style={{ touchAction: "none" }}
        >
          {track.cover_url ? (
            <img
              src={track.cover_url}
              alt={track.title}
              className="absolute inset-0 w-full h-full object-cover"
              draggable={false}
            />
          ) : (
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-primary/10 to-secondary flex items-center justify-center">
              <Music className="w-20 h-20 text-primary/25" />
            </div>
          )}

          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/15 to-transparent pointer-events-none" />

          {/* Genre badge */}
          {track.genre && (
            <div className="absolute top-4 left-4 pointer-events-none">
              <Badge className="bg-white/95 text-foreground border-0 shadow text-xs font-semibold">
                {genreLabels[track.genre] || track.genre}
              </Badge>
            </div>
          )}

          {/* SKIP stamp */}
          <motion.div
            style={{ opacity: skipOpacity }}
            className="absolute top-7 left-5 pointer-events-none"
          >
            <div
              className="border-4 border-muted-foreground/60 rounded-xl px-4 py-1.5"
              style={{ transform: "rotate(-15deg)" }}
            >
              <span className="text-muted-foreground/70 font-black text-2xl tracking-widest uppercase">
                Skip
              </span>
            </div>
          </motion.div>

          {/* REVIEW stamp */}
          <motion.div
            style={{ opacity: reviewOpacity }}
            className="absolute top-7 right-5 pointer-events-none"
          >
            <div
              className="border-4 border-primary rounded-xl px-4 py-1.5"
              style={{ transform: "rotate(15deg)" }}
            >
              <span className="text-primary font-black text-2xl tracking-widest uppercase">
                Review
              </span>
            </div>
          </motion.div>

          {/* Click zone hints */}
          <div className="absolute inset-0 flex pointer-events-none">
            <div className="flex-1 flex items-center justify-start px-4 opacity-0 group-hover:opacity-30">
              <span className="text-white text-xs font-medium">← Skip</span>
            </div>
            <div className="flex-1 flex items-center justify-end px-4 opacity-0 group-hover:opacity-30">
              <span className="text-white text-xs font-medium">Review →</span>
            </div>
          </div>

          {/* Title overlay */}
          <div className="absolute bottom-0 left-0 right-0 px-5 pb-4 pt-8">
            <h3 className="text-white font-heading font-bold text-2xl leading-tight drop-shadow pointer-events-none">
              {track.title}
            </h3>
            <button
              onPointerDown={(e) => e.stopPropagation()}
              onClick={(e) => { e.stopPropagation(); if (track.created_by_id) navigate(`/profile?id=${track.created_by_id}`); }}
              className="text-white/75 text-sm font-medium mt-0.5 drop-shadow hover:text-white hover:underline transition-colors text-left"
            >
              {track.artist_name}
            </button>
          </div>
        </div>

        {/* Stats row */}
        <div className="px-5 py-3 flex items-center gap-3 bg-white shrink-0">
          <div className="flex items-center gap-1.5">
            <Star className="w-4 h-4 text-amber-400 fill-amber-400 shrink-0" />
            <span className="text-sm font-semibold text-foreground">
              {track.avg_rating ? track.avg_rating.toFixed(1) : "New"}
            </span>
          </div>
          <div className="flex items-center gap-1.5 text-muted-foreground shrink-0">
            <MessageSquare className="w-4 h-4" />
            <span className="text-sm">{track.feedback_count || 0}</span>
          </div>
          {(track.feedback_request || track.description) && (
            <p className="text-xs text-muted-foreground flex-1 truncate italic">
              "{track.feedback_request || track.description}"
            </p>
          )}
        </div>

        {/* Action bar */}
        <div className="flex border-t border-border shrink-0">
          <button
            onPointerDown={(e) => e.stopPropagation()}
            onClick={(e) => { e.stopPropagation(); flySkip(); }}
            className="flex-1 py-4 flex items-center justify-center gap-2 text-muted-foreground hover:bg-muted/40 transition-colors"
          >
            <X className="w-4 h-4" />
            <span className="text-sm font-medium">Skip</span>
          </button>
          <div className="w-px bg-border" />
          <button
            onPointerDown={(e) => e.stopPropagation()}
            onClick={(e) => { e.stopPropagation(); flyReview(); }}
            className="flex-1 py-4 flex items-center justify-center gap-2 text-primary hover:bg-primary/5 transition-colors"
          >
            <MessageCircle className="w-4 h-4" />
            <span className="text-sm font-medium">Review</span>
          </button>
        </div>
      </div>
    </motion.div>
  );
}