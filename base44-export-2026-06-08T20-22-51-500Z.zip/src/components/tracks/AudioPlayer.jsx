import { useState, useRef, useEffect } from "react";
import { Play, Pause, Volume2, VolumeX } from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";

export default function AudioPlayer({ src }) {
  const audioRef = useRef(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.8);
  const [muted, setMuted] = useState(false);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleTime = () => setCurrentTime(audio.currentTime);
    const handleLoaded = () => setDuration(audio.duration);
    const handleEnded = () => setIsPlaying(false);

    audio.addEventListener("timeupdate", handleTime);
    audio.addEventListener("loadedmetadata", handleLoaded);
    audio.addEventListener("ended", handleEnded);

    return () => {
      audio.removeEventListener("timeupdate", handleTime);
      audio.removeEventListener("loadedmetadata", handleLoaded);
      audio.removeEventListener("ended", handleEnded);
    };
  }, [src]);

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const seek = (value) => {
    if (!audioRef.current) return;
    audioRef.current.currentTime = value[0];
    setCurrentTime(value[0]);
  };

  const handleVolume = (value) => {
    if (!audioRef.current) return;
    audioRef.current.volume = value[0];
    setVolume(value[0]);
    setMuted(value[0] === 0);
  };

  const formatTime = (t) => {
    if (!t || isNaN(t)) return "0:00";
    const m = Math.floor(t / 60);
    const s = Math.floor(t % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  };

  return (
    <div className="rounded-2xl border border-border bg-white p-5">
      <audio ref={audioRef} src={src} />

      {/* Waveform bars */}
      <div className="flex items-end justify-center gap-[3px] h-14 mb-4">
        {[...Array(50)].map((_, i) => {
          const progress = duration > 0 ? currentTime / duration : 0;
          const isActive = (i / 50) <= progress;
          return (
            <div
              key={i}
              className={`w-1 rounded-full transition-colors duration-100 ${isActive ? "bg-primary" : "bg-muted"}`}
              style={{ height: `${10 + Math.sin(i * 0.5) * 18 + (i % 3) * 5}px` }}
            />
          );
        })}
      </div>

      {/* Controls */}
      <div className="flex items-center gap-3">
        <button
          onClick={togglePlay}
          className="w-10 h-10 rounded-full btn-primary flex items-center justify-center text-white shadow-sm flex-shrink-0"
        >
          {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
        </button>

        <span className="text-xs font-mono text-muted-foreground w-9 text-right flex-shrink-0">
          {formatTime(currentTime)}
        </span>

        <Slider
          value={[currentTime]}
          max={duration || 100}
          step={0.1}
          onValueChange={seek}
          className="flex-1"
        />

        <span className="text-xs font-mono text-muted-foreground w-9 flex-shrink-0">
          {formatTime(duration)}
        </span>

        <Button
          variant="ghost"
          size="icon"
          onClick={() => {
            setMuted(!muted);
            if (audioRef.current) audioRef.current.muted = !muted;
          }}
          className="text-muted-foreground hover:text-foreground w-8 h-8 flex-shrink-0"
        >
          {muted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
        </Button>

        <Slider
          value={[muted ? 0 : volume]}
          max={1}
          step={0.01}
          onValueChange={handleVolume}
          className="w-16 flex-shrink-0"
        />
      </div>
    </div>
  );
}