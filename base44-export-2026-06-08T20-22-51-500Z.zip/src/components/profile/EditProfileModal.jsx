const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Upload, Loader2, AtSign } from "lucide-react";

export default function EditProfileModal({ open, onClose, user, onSaved }) {
  const [displayName, setDisplayName] = useState(user?.display_name || user?.full_name || "");
  const [username, setUsername] = useState(user?.username || "");
  const [bio, setBio] = useState(user?.bio || "");
  const [avatarUrl, setAvatarUrl] = useState(user?.avatar_url || "");
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const handleAvatarUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await db.integrations.Core.UploadFile({ file });
      setAvatarUrl(file_url);
    } finally {
      setUploading(false);
    }
  };

  const handleUsernameChange = (val) => {
    const clean = val.toLowerCase().replace(/[^a-z0-9_]/g, "");
    setUsername(clean);
    setError("");
  };

  const handleSave = async () => {
    setError("");
    if (!username.trim()) {
      setError("Username is required.");
      return;
    }
    if (username.length < 3) {
      setError("Username must be at least 3 characters.");
      return;
    }
    setSaving(true);
    try {
      // Check uniqueness (skip if unchanged)
      if (username !== user?.username) {
        const existing = await db.entities.User.filter({ username });
        if (existing.length > 0) {
          setError("That username is already taken.");
          return;
        }
      }
      await db.auth.updateMe({ display_name: displayName, username, bio, avatar_url: avatarUrl });
      onSaved();
      onClose();
    } catch (err) {
      setError(err.message || "Failed to save changes. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const initials = (displayName || user?.full_name || "?")
    .split(" ").map(w => w[0]).join("").toUpperCase().slice(0, 2);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Edit Profile</DialogTitle>
        </DialogHeader>
        <div className="space-y-5 pt-2">
          {/* Avatar */}
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-primary/10 border-2 border-primary/20 flex items-center justify-center overflow-hidden flex-shrink-0">
              {avatarUrl ? (
                <img src={avatarUrl} alt="avatar" className="w-full h-full object-cover" />
              ) : (
                <span className="text-xl font-heading font-bold text-primary">{initials}</span>
              )}
            </div>
            <div>
              <Label className="cursor-pointer">
                <div className="flex items-center gap-2 text-sm text-primary font-medium hover:underline">
                  {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                  {uploading ? "Uploading…" : "Upload photo"}
                </div>
                <input type="file" accept="image/*" className="hidden" onChange={handleAvatarUpload} disabled={uploading} />
              </Label>
              {avatarUrl && (
                <button onClick={() => setAvatarUrl("")} className="text-xs text-muted-foreground hover:text-destructive mt-1 block">
                  Remove photo
                </button>
              )}
            </div>
          </div>

          {error && (
            <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-destructive text-sm">
              {error}
            </div>
          )}

          {/* Username */}
          <div className="space-y-1.5">
            <Label>
              Username <span className="text-destructive">*</span>
            </Label>
            <div className="relative">
              <AtSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                value={username}
                onChange={(e) => handleUsernameChange(e.target.value)}
                placeholder="yourhandle"
                className="pl-9"
              />
            </div>
            {username.length >= 3 && (
              <p className="text-xs text-muted-foreground">Your handle: <span className="text-foreground font-medium">@{username}</span></p>
            )}
            <p className="text-xs text-muted-foreground">
              Only lowercase letters, numbers, and underscores.
            </p>
          </div>

          {/* Display name */}
          <div className="space-y-1.5">
            <Label>Display Name</Label>
            <Input value={displayName} onChange={e => setDisplayName(e.target.value)} placeholder="Your artist name" />
          </div>

          {/* Bio */}
          <div className="space-y-1.5">
            <Label>Bio</Label>
            <Textarea
              value={bio}
              onChange={e => setBio(e.target.value)}
              placeholder="Tell the community about yourself and your music…"
              className="resize-none h-24"
            />
          </div>

          <div className="flex justify-end gap-2 pt-1">
            <Button variant="outline" onClick={onClose} disabled={saving}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving || uploading}>
              {saving ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : null}
              Save Changes
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}