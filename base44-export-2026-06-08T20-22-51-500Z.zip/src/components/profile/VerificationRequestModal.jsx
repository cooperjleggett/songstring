const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { BadgeCheck, Loader2, CheckCircle2 } from "lucide-react";

export default function VerificationRequestModal({ open, onClose, user, onSaved }) {
  const [reason, setReason] = useState(user?.verification_reason || "");
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState("");

  const alreadyRequested = user?.verification_requested;

  const handleSubmit = async () => {
    if (!reason.trim() || reason.trim().length < 20) {
      setError("Please provide at least 20 characters explaining why you should be verified.");
      return;
    }
    setSaving(true);
    setError("");
    try {
      await db.auth.updateMe({ verification_requested: true, verification_reason: reason.trim() });
      setDone(true);
      onSaved();
    } catch (err) {
      setError(err.message || "Failed to submit request. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BadgeCheck className="w-5 h-5 text-primary" />
            Request Verification
          </DialogTitle>
        </DialogHeader>

        {done ? (
          <div className="py-6 text-center space-y-3">
            <div className="w-14 h-14 rounded-full bg-green-100 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-7 h-7 text-green-600" />
            </div>
            <h3 className="font-heading font-semibold text-foreground">Request Submitted!</h3>
            <p className="text-sm text-muted-foreground">
              Your verification request has been submitted. Our team will review it and get back to you.
            </p>
            <Button onClick={onClose} className="mt-2">Done</Button>
          </div>
        ) : (
          <div className="space-y-4 pt-2">
            {alreadyRequested && !done && (
              <div className="p-3 rounded-lg bg-amber-50 border border-amber-200 text-amber-800 text-sm">
                You've already submitted a verification request. You can update your reason below.
              </div>
            )}

            <div className="rounded-xl border border-border bg-accent/50 p-4 space-y-2">
              <p className="text-sm font-medium text-foreground">What is a verified badge?</p>
              <p className="text-xs text-muted-foreground leading-relaxed">
                The <BadgeCheck className="w-3.5 h-3.5 text-primary inline mx-0.5" /> badge confirms you're a notable, authentic creator on Songstring. Verification is granted at admin discretion.
              </p>
            </div>

            <div className="space-y-1.5">
              <Label>
                Why should you be verified? <span className="text-destructive">*</span>
              </Label>
              <Textarea
                value={reason}
                onChange={e => { setReason(e.target.value); setError(""); }}
                placeholder="Tell us about your music career, social presence, achievements, or why you're a notable creator…"
                className="resize-none h-32"
              />
              <p className="text-xs text-muted-foreground">{reason.length} / 500 characters</p>
            </div>

            {error && (
              <p className="text-sm text-destructive">{error}</p>
            )}

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={onClose}>Cancel</Button>
              <Button onClick={handleSubmit} disabled={saving || !reason.trim()}>
                {saving ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : null}
                {alreadyRequested ? "Update Request" : "Submit Request"}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}