const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React from "react";
import { Upload, MessageSquare, Star } from "lucide-react";
import SongstringLogo from "@/components/SongstringLogo";

const features = [
  { icon: Upload, text: "Upload your tracks and demos" },
  { icon: MessageSquare, text: "Get honest feedback from real creators" },
  { icon: Star, text: "Rate and review the community's work" },
];

export default function AuthLayout({ title, subtitle, footer, children }) {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Hero section */}
      <div
        className="relative w-full flex flex-col items-center pt-10 pb-16"
        style={{
          backgroundImage: "url('https://media.db.com/images/public/6a1f2d5bbe0ec39038b9660e/bfd24467c_generated_image.png')",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        {/* Overlay for readability */}
        <div className="absolute inset-0 bg-black/40" />

        {/* Logo top-left */}
        <div className="relative z-10 absolute top-6 left-6 flex items-center gap-2.5">
          <SongstringLogo size={36} />
          <span className="text-xl font-heading font-bold text-white">Songstring</span>
        </div>

        {/* Hero copy */}
        <div className="relative z-10 text-center px-6 max-w-lg mt-16">
          <h2 className="text-4xl font-heading font-bold text-white leading-tight mb-4">
            Your music,<br />elevated by community.
          </h2>
          <p className="text-white/80 text-base leading-relaxed">
            Songstring is the feedback platform built for independent artists. Upload your work-in-progress, get targeted critiques, and grow faster.
          </p>
        </div>

        {/* Feature cards */}
        <div className="relative z-10 grid grid-cols-1 sm:grid-cols-3 gap-4 mt-10 px-6 w-full max-w-2xl">
          {features.map(({ icon: FIcon, text }) => (
            <div
              key={text}
              className="rounded-2xl bg-white/95 p-5 flex flex-col items-center text-center gap-3 shadow-lg"
            >
              <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                <FIcon className="w-4 h-4 text-white" />
              </div>
              <p className="text-gray-800 font-semibold text-sm leading-snug">{text}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Form section */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-10 bg-background">
        <div className="w-full max-w-sm">
          <div className="mb-6">
            <h1 className="text-2xl font-heading font-bold text-foreground">{title}</h1>
            {subtitle && <p className="text-muted-foreground text-sm mt-1">{subtitle}</p>}
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-sm border border-border">
            {children}
          </div>

          {footer && (
            <p className="text-center text-sm text-muted-foreground mt-5">{footer}</p>
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="text-center pb-6">
        <p className="text-muted-foreground/40 text-xs">© 2026 Songstring</p>
      </div>
    </div>
  );
}