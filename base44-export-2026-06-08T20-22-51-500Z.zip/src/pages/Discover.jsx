const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect } from "react";

import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { Search, Music2, RefreshCw } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import SwipeCard from "@/components/tracks/SwipeCard";

const genres = [
  { value: "all", label: "All" },
  { value: "hip_hop", label: "Hip Hop" },
  { value: "rnb", label: "R&B" },
  { value: "pop", label: "Pop" },
  { value: "rock", label: "Rock" },
  { value: "electronic", label: "Electronic" },
  { value: "jazz", label: "Jazz" },
  { value: "indie", label: "Indie" },
  { value: "latin", label: "Latin" },
  { value: "country", label: "Country" },
  { value: "other", label: "Other" },
];

export default function Discover() {
  const [search, setSearch] = useState("");
  const [activeGenre, setActiveGenre] = useState("all");
  const [dismissed, setDismissed] = useState(new Set());
  const navigate = useNavigate();

  const { data: tracks = [], isLoading } = useQuery({
    queryKey: ["tracks"],
    queryFn: () => db.entities.Track.list("-created_date", 100),
  });

  // Reset dismissed when filters change
  useEffect(() => {
    setDismissed(new Set());
  }, [search, activeGenre]);

  const filtered = tracks.filter((t) => {
    const matchSearch =
      !search ||
      t.title?.toLowerCase().includes(search.toLowerCase()) ||
      t.artist_name?.toLowerCase().includes(search.toLowerCase());
    const matchGenre = activeGenre === "all" || t.genre === activeGenre;
    const notDismissed = !dismissed.has(t.id);
    return matchSearch && matchGenre && notDismissed;
  });

  const currentTrack = filtered[0];
  const nextTrack = filtered[1];
  const allDone = !isLoading && filtered.length === 0;

  const handleSkip = () => {
    if (currentTrack) {
      setDismissed((prev) => new Set([...prev, currentTrack.id]));
    }
  };

  const handleReview = () => {
    if (currentTrack) {
      setDismissed((prev) => new Set([...prev, currentTrack.id]));
      navigate(`/track?id=${currentTrack.id}`);
    }
  };

  const handleReset = () => setDismissed(new Set());

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 pt-8 pb-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <h1 className="text-3xl font-heading font-bold text-foreground tracking-tight">
            Discover
          </h1>
          <p className="text-muted-foreground mt-0.5 text-sm">
            Swipe right to skip · Swipe left to review
          </p>
        </motion.div>

        {/* Search */}
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.08 }}
          className="relative mb-4"
        >
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search tracks or artists..."
            className="pl-10 h-11 bg-secondary border-border rounded-xl text-sm"
          />
        </motion.div>

        {/* Genre chips */}
        <div className="flex gap-2 overflow-x-auto pb-2 mb-6 scrollbar-hide">
          {genres.map((g) => (
            <button
              key={g.value}
              onClick={() => setActiveGenre(g.value)}
              className={`flex-shrink-0 px-3.5 py-1.5 rounded-full text-xs font-medium transition-all border ${
                activeGenre === g.value
                  ? "btn-primary text-white border-transparent shadow-sm"
                  : "bg-secondary border-border text-muted-foreground hover:text-foreground"
              }`}
            >
              {g.label}
            </button>
          ))}
        </div>
      </div>

      {/* Swipe area */}
      <div className="px-4 sm:px-6 pb-16">
        {isLoading ? (
          <div className="flex items-center justify-center h-[480px]">
            <div className="w-7 h-7 border-4 border-muted border-t-primary rounded-full animate-spin" />
          </div>
        ) : allDone ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex flex-col items-center justify-center h-[480px] text-center space-y-4"
          >
            <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center">
              <Music2 className="w-9 h-9 text-muted-foreground/40" />
            </div>
            <div>
              <h3 className="font-heading font-semibold text-lg text-foreground">
                You're all caught up!
              </h3>
              <p className="text-muted-foreground text-sm mt-1">
                {dismissed.size > 0
                  ? "You've gone through all the tracks."
                  : "No tracks match your search. Try a different filter."}
              </p>
            </div>
            {dismissed.size > 0 && (
              <Button variant="outline" size="sm" onClick={handleReset} className="gap-2">
                <RefreshCw className="w-3.5 h-3.5" />
                See them again
              </Button>
            )}
            {dismissed.size === 0 && (
              <Button asChild size="sm" className="btn-primary text-white border-0">
                <a href="/upload">Upload a Track</a>
              </Button>
            )}
          </motion.div>
        ) : (
          <div className="flex flex-col items-center gap-4">
            {/* Card Stack */}
            <div
              className="relative w-full"
              style={{
                maxWidth: "360px",
                height: "clamp(400px, 68vh, 520px)",
                margin: "0 auto",
              }}
            >
              {/* Back card */}
              {nextTrack && (
                <div
                  className="absolute inset-0 pointer-events-none"
                  style={{
                    zIndex: 5,
                    transform: "scale(0.94) translateY(12px)",
                    transformOrigin: "center bottom",
                  }}
                >
                  <div className="w-full h-full rounded-3xl overflow-hidden border border-border/40 bg-secondary shadow-md">
                    {nextTrack.cover_url ? (
                      <img
                        src={nextTrack.cover_url}
                        alt=""
                        className="w-full h-full object-cover opacity-50"
                        draggable={false}
                      />
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-muted to-secondary" />
                    )}
                  </div>
                </div>
              )}

              {/* Top card */}
              {currentTrack && (
                <SwipeCard
                  key={currentTrack.id}
                  track={currentTrack}
                  onSkip={handleSkip}
                  onReview={handleReview}
                />
              )}
            </div>

            {/* Progress */}
            <p className="text-xs text-muted-foreground">
              {filtered.length} track{filtered.length !== 1 ? "s" : ""} remaining
            </p>
          </div>
        )}
      </div>
    </div>
  );
}