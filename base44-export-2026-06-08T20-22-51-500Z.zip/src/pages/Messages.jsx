const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect, useRef } from "react";

import { useAuth } from "@/lib/AuthContext";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Send, MessageSquare, ArrowLeft, PenSquare } from "lucide-react";
import { Link } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";
import NewMessageModal from "@/components/messages/NewMessageModal";

export default function Messages() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [selectedConvo, setSelectedConvo] = useState(null);
  const [newMessage, setNewMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [showNewMessage, setShowNewMessage] = useState(false);
  const messagesEndRef = useRef(null);

  // All messages involving me
  const { data: allMessages = [] } = useQuery({
    queryKey: ["messages", user?.id],
    queryFn: async () => {
      const sent = await db.entities.Message.filter({ sender_id: user.id }, "-created_date", 100);
      const received = await db.entities.Message.filter({ recipient_id: user.id }, "-created_date", 100);
      return [...sent, ...received].sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
    },
    enabled: !!user?.id,
    refetchInterval: 5000,
  });

  // Collect unique other user IDs and fetch their profiles for usernames
  const otherUserIds = [...new Set(
    allMessages.map(m => m.sender_id === user?.id ? m.recipient_id : m.sender_id).filter(Boolean)
  )];

  const { data: otherUsers = [] } = useQuery({
    queryKey: ["messageUsers", otherUserIds.join(",")],
    queryFn: () => Promise.all(
      otherUserIds.map(id => db.entities.User.filter({ id }).then(r => r[0]).catch(() => null))
    ),
    enabled: otherUserIds.length > 0,
  });

  const userMap = {};
  otherUsers.forEach(u => { if (u) userMap[u.id] = u; });

  const getDisplayName = (userId, fallback) => {
    const u = userMap[userId];
    if (u?.username) return `@${u.username}`;
    if (u?.display_name) return u.display_name;
    if (u?.full_name) return u.full_name;
    return fallback || "User";
  };

  // Build conversation list
  const conversations = (() => {
    const map = {};
    allMessages.forEach(m => {
      const otherId = m.sender_id === user?.id ? m.recipient_id : m.sender_id;
      const fallbackName = m.sender_id === user?.id ? m.recipient_name : m.sender_name;
      if (!map[otherId]) {
        map[otherId] = { userId: otherId, name: getDisplayName(otherId, fallbackName), lastMessage: m, unread: 0 };
      }
      if (m.recipient_id === user?.id && !m.read) {
        map[otherId].unread++;
      }
    });
    return Object.values(map).sort((a, b) => new Date(b.lastMessage.created_date) - new Date(a.lastMessage.created_date));
  })();

  // Messages in selected conversation
  const convoMessages = selectedConvo
    ? allMessages.filter(m =>
        (m.sender_id === user?.id && m.recipient_id === selectedConvo.userId) ||
        (m.recipient_id === user?.id && m.sender_id === selectedConvo.userId)
      ).sort((a, b) => new Date(a.created_date) - new Date(b.created_date))
    : [];

  // Mark messages as read when opening a conversation
  useEffect(() => {
    if (!selectedConvo || !user) return;
    const unread = allMessages.filter(m => m.recipient_id === user.id && m.sender_id === selectedConvo.userId && !m.read);
    unread.forEach(m => db.entities.Message.update(m.id, { read: true }));
  }, [selectedConvo, allMessages, user]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [convoMessages.length]);

  const sendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !selectedConvo) return;
    setSending(true);
    const senderName = user?.username ? `@${user.username}` : (user?.display_name || user?.full_name || user?.email);
    await db.entities.Message.create({
      sender_id: user.id,
      recipient_id: selectedConvo.userId,
      sender_name: senderName,
      recipient_name: selectedConvo.name,
      content: newMessage.trim(),
      read: false,
    });
    setNewMessage("");
    queryClient.invalidateQueries({ queryKey: ["messages", user?.id] });
    setSending(false);
  };

  const handleNewConversation = (convo) => {
    queryClient.invalidateQueries({ queryKey: ["messages", user?.id] });
    setSelectedConvo(convo);
  };

  const totalUnread = conversations.reduce((sum, c) => sum + c.unread, 0);

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        <div className="mb-6 flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-heading font-bold text-foreground">Messages</h1>
            <p className="text-muted-foreground text-sm mt-0.5">Private conversations with other artists.</p>
          </div>
          <Button onClick={() => setShowNewMessage(true)} size="sm" className="gap-1.5">
            <PenSquare className="w-4 h-4" />
            New Message
          </Button>
        </div>

        <div className="rounded-2xl border border-border bg-card overflow-hidden" style={{ height: "calc(100vh - 200px)", minHeight: 500 }}>
          <div className="flex h-full">
            {/* Sidebar */}
            <div className={`w-full sm:w-72 border-r border-border flex flex-col ${selectedConvo ? "hidden sm:flex" : "flex"}`}>
              <div className="p-4 border-b border-border flex items-center justify-between">
                <p className="text-sm font-semibold text-foreground">
                  Conversations
                  {totalUnread > 0 && (
                    <span className="ml-1.5 text-xs bg-primary text-primary-foreground px-1.5 py-0.5 rounded-full">{totalUnread}</span>
                  )}
                </p>
                <button
                  onClick={() => setShowNewMessage(true)}
                  className="text-muted-foreground hover:text-primary transition-colors"
                  title="New message"
                >
                  <PenSquare className="w-4 h-4" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto">
                {conversations.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full text-center p-6">
                    <MessageSquare className="w-8 h-8 text-muted-foreground/30 mb-2" />
                    <p className="text-muted-foreground text-sm">No conversations yet.</p>
                    <button
                      onClick={() => setShowNewMessage(true)}
                      className="text-primary text-xs font-medium mt-2 hover:underline"
                    >
                      Start a conversation
                    </button>
                  </div>
                ) : (
                  conversations.map(convo => (
                    <button
                      key={convo.userId}
                      onClick={() => setSelectedConvo(convo)}
                      className={`w-full text-left px-4 py-3.5 border-b border-border transition-colors hover:bg-accent ${selectedConvo?.userId === convo.userId ? "bg-accent" : ""}`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                          <span className="text-sm font-bold text-primary">
                            {convo.name.replace("@", "")[0]?.toUpperCase() || "?"}
                          </span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <p className="text-sm font-semibold text-foreground truncate">{convo.name}</p>
                            {convo.unread > 0 && (
                              <span className="ml-2 flex-shrink-0 w-5 h-5 bg-primary rounded-full text-xs text-white flex items-center justify-center">{convo.unread}</span>
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground truncate mt-0.5">{convo.lastMessage.content}</p>
                        </div>
                      </div>
                    </button>
                  ))
                )}
              </div>
            </div>

            {/* Chat area */}
            <div className={`flex-1 flex flex-col ${!selectedConvo ? "hidden sm:flex" : "flex"}`}>
              {!selectedConvo ? (
                <div className="flex-1 flex flex-col items-center justify-center text-center p-8 gap-3">
                  <MessageSquare className="w-12 h-12 text-muted-foreground/20" />
                  <p className="text-muted-foreground text-sm">Select a conversation or start a new one</p>
                  <Button onClick={() => setShowNewMessage(true)} size="sm" variant="outline" className="gap-1.5">
                    <PenSquare className="w-3.5 h-3.5" />
                    New Message
                  </Button>
                </div>
              ) : (
                <>
                  {/* Chat header */}
                  <div className="p-4 border-b border-border flex items-center gap-3">
                    <button onClick={() => setSelectedConvo(null)} className="sm:hidden text-muted-foreground hover:text-foreground">
                      <ArrowLeft className="w-5 h-5" />
                    </button>
                    <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                      <span className="text-sm font-bold text-primary">
                        {selectedConvo.name.replace("@", "")[0]?.toUpperCase() || "?"}
                      </span>
                    </div>
                    <Link to={`/profile?id=${selectedConvo.userId}`} className="font-semibold text-sm text-foreground hover:text-primary transition-colors">
                      {selectedConvo.name}
                    </Link>
                  </div>

                  {/* Messages */}
                  <div className="flex-1 overflow-y-auto p-4 space-y-3">
                    <AnimatePresence initial={false}>
                      {convoMessages.map(m => {
                        const isMe = m.sender_id === user?.id;
                        return (
                          <motion.div
                            key={m.id}
                            initial={{ opacity: 0, y: 6 }}
                            animate={{ opacity: 1, y: 0 }}
                            className={`flex ${isMe ? "justify-end" : "justify-start"}`}
                          >
                            <div className={`max-w-[72%] rounded-2xl px-4 py-2.5 ${isMe ? "bg-primary text-primary-foreground rounded-br-sm" : "bg-secondary text-foreground rounded-bl-sm"}`}>
                              <p className="text-sm leading-relaxed">{m.content}</p>
                              <p className={`text-xs mt-1 ${isMe ? "text-primary-foreground/60" : "text-muted-foreground"}`}>
                                {format(new Date(m.created_date), "h:mm a")}
                              </p>
                            </div>
                          </motion.div>
                        );
                      })}
                    </AnimatePresence>
                    <div ref={messagesEndRef} />
                  </div>

                  {/* Input */}
                  <form onSubmit={sendMessage} className="p-4 border-t border-border flex gap-2">
                    <Input
                      value={newMessage}
                      onChange={e => setNewMessage(e.target.value)}
                      placeholder="Type a message..."
                      className="flex-1 bg-secondary border-border text-sm"
                    />
                    <Button type="submit" disabled={sending || !newMessage.trim()} className="btn-primary text-white border-0 px-3">
                      <Send className="w-4 h-4" />
                    </Button>
                  </form>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      <NewMessageModal
        open={showNewMessage}
        onClose={() => setShowNewMessage(false)}
        currentUser={user}
        onConversationStart={handleNewConversation}
      />
    </div>
  );
}