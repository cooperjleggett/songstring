const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };


import { useAuth } from "@/lib/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { Music, Star, MessageSquare, TrendingUp, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import TrackCard from "@/components/tracks/TrackCard";
import FeedbackCharts from "@/components/dashboard/FeedbackCharts";

export default function Dashboard() {
  const { user } = useAuth();

  const { data: myTracks = [], isLoading: loadingTracks } = useQuery({
    queryKey: ["myTracks", user?.id],
    queryFn: () => db.entities.Track.filter({ created_by_id: user?.id }, "-created_date"),
    enabled: !!user?.id,
  });

  const { data: myFeedbacks = [] } = useQuery({
    queryKey: ["myFeedbacks", user?.id],
    queryFn: () => db.entities.Feedback.filter({ created_by_id: user?.id }, "-created_date"),
    enabled: !!user?.id,
  });

  const totalFeedbackReceived = myTracks.reduce((sum, t) => sum + (t.feedback_count || 0), 0);
  const ratedTracks = myTracks.filter(t => t.avg_rating > 0);
  const avgRating = ratedTracks.length > 0
    ? ratedTracks.reduce((sum, t) => sum + t.avg_rating, 0) / ratedTracks.length
    : 0;

  const stats = [
    { label: "Tracks Uploaded", value: myTracks.length, icon: Music },
    { label: "Feedback Received", value: totalFeedbackReceived, icon: MessageSquare },
    { label: "Avg Rating", value: avgRating ? avgRating.toFixed(1) : "—", icon: Star },
    { label: "Reviews Given", value: myFeedbacks.length, icon: TrendingUp },