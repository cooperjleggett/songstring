const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";

import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/AuthContext";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, Star, MessageSquare, Music, Calendar, Send, Share2, Check, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { motion } from "framer-motion";
import { format } from "date-fns";
import AudioPlayer from "@/components/tracks/AudioPlayer";
import FeedbackForm from "@/components/feedback/FeedbackForm";
import FeedbackItem from "@/components/feedback/FeedbackItem";

const genreLabels = {
  hip_hop: "Hip Hop", rnb: "R&B", pop: "Pop", rock: "Rock",
  electronic: "Electronic", jazz: "Jazz", country: "Country",
  latin: "Latin", indie: "Indie", other: "Other"
};

export default function TrackDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const trackId = urlParams.get("id");
  const { user } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [copied, setCopied] = useState(false);
  const [confirmDeleteTrack, setConfirmDeleteTrack] = useState(false);

  const { data: track, isLoading } = useQuery({
    queryKey: ["track", trackId],
    queryFn: async () => {
      const tracks = await db.entities.Track.filter({ id: trackId });
      return tracks[0];
    },
    enabled: !!trackId,
  });

  const { data: feedbacks = [] } = useQuery({
    queryKey: ["feedback", trackId],
    queryFn: () => db.entities.Feedback.filter({ track_id: trackId }, "-created_date"),
    enabled: !!trackId,
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-7 h-7 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!track) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen gap-4">
        <p className="text-muted-foreground text-sm">Track not found</p>
        <Button asChild variant="outline" size="sm">
          <Link to="/">Back to Discover</Link>
        </Button>
      </div>
    );
  }

  const isOwner = user?.id === track.created_by_id;
  const isAdmin = user?.role === "admin";

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDeleteTrack = async () => {
    if (!confirmDeleteTrack) {
      setConfirmDeleteTrack(true);
      setTimeout(() => setConfirmDeleteTrack(false), 4000);
      return;
    }
    await db.entities.Track.delete(track.id);
    navigate("/dashboard");
  };

  const handleDeleteFeedback = async (feedbackId) => {
    const fb = feedbacks.find(f => f.id === feedbackId);
    await db.entities.Feedback.delete(feedbackId);
    // Update track stats
    const remaining = feedbacks.filter(f => f.id !== feedbackId);
    const newCount = remaining.length;
    const newAvg = newCount > 0
      ? remaining.reduce((s, f) => s + f.rating, 0) / newCount
      : 0;
    await db.entities.Track.update(trackId, {
      feedback_count: newCount,
      avg_rating: newAvg,
    });
    queryClient.invalidateQueries({ queryKey: ["feedback", trackId] });
    queryClient.invalidateQueries({ queryKey: ["track", trackId] });
  };

  const handleMessageArtist = async () => {
    const senderName = user.username ? `@${user.username}` : (user.display_name || user.full_name || user.email);
    await db.entities.Message.create({
      sender_id: user.id,
      recipient_id: track.created_by_id,
      sender_name: senderName,
      recipient_name: track.artist_name,
      content: `Hey! I wanted to chat about your track "${track.title}".`,
      read: false,
    });
    queryClient.invalidateQueries({ queryKey: ["messages", user?.id] });
    navigate("/messages");
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
        {/* Back */}
        <Link to="/" className="inline-flex items-center gap-1.5 text-muted-foreground hover:text-foreground mb-6 transition-colors text-sm">
          <ArrowLeft className="w-4 h-4" />
          Back to Discover
        </Link>

        <div className="grid lg:grid-cols-[1fr_300px] gap-8">
          {/* Main */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-5"
          >
            {/* Track header */}
            <div className="flex gap-4">
              <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-xl bg-muted flex items-center justify-center overflow-hidden flex-shrink-0 border border-border">
                {track.cover_url ? (
                  <img src={track.cover_url} alt={track.title} className="w-full h-full object-cover" />
                ) : (
                  <Music className="w-9 h-9 text-muted-foreground/40" />
                )}
              </div>
              <div className="space-y-1.5 min-w-0 pt-1 flex-1">
                <h1 className="text-2xl sm:text-3xl font-heading font-bold truncate">{track.title}</h1>
                <Link
                  to={`/profile?id=${track.created_by_id}`}
                  className="text-muted-foreground text-sm font-medium hover:text-primary transition-colors"
                >
                  {track.artist_name}
                </Link>
                <div className="flex flex-wrap items-center gap-2 pt-0.5">
                  {track.genre && (
                    <Badge variant="outline" className="border-border text-xs font-medium text-muted-foreground">
                      {genreLabels[track.genre] || track.genre}
                    </Badge>
                  )}
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                    <span className="font-medium text-foreground">{track.avg_rating ? track.avg_rating.toFixed(1) : "—"}</span>
                  </div>
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>{track.feedback_count || 0} reviews</span>
                  </div>
                  {track.created_date && (
                    <div className="flex items-center gap-1 text-sm text-muted-foreground">
                      <Calendar className="w-3.5 h-3.5" />
                      <span>{format(new Date(track.created_date), "MMM d, yyyy")}</span>
                    </div>
                  )}
                  <button
                    onClick={handleShare}
                    className="flex items-center gap-1 text-sm text-muted-foreground hover:text-primary transition-colors"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Share2 className="w-3.5 h-3.5" />}
                    <span>{copied ? "Copied!" : "Share"}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Audio Player */}
            <AudioPlayer src={track.audio_url} />

            {/* Description */}
            {track.description && (
              <div className="rounded-xl border border-border bg-white p-4 space-y-1.5">
                <h3 className="font-heading font-semibold text-sm">About This Track</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{track.description}</p>
              </div>
            )}

            {/* Feedback request */}
            {track.feedback_request && (
              <div className="rounded-xl border border-primary/20 bg-primary/5 p-4 space-y-1.5">
                <h3 className="font-heading font-semibold text-sm text-primary">Feedback Requested</h3>
                <p className="text-sm text-foreground/80 leading-relaxed">{track.feedback_request}</p>
              </div>
            )}

            <Separator />

            {/* Feedback list */}
            <div className="space-y-3">
              <h2 className="font-heading font-semibold text-base">
                Community Feedback <span className="text-muted-foreground font-normal">({feedbacks.length})</span>
              </h2>
              {feedbacks.length === 0 ? (
                <p className="text-muted-foreground text-sm py-4 text-center">
                  No feedback yet. Be the first to share your thoughts!
                </p>
              ) : (
                <div className="space-y-2.5">
                  {feedbacks.map((fb, i) => (
                    <FeedbackItem
                      key={fb.id}
                      feedback={fb}
                      index={i}
                      currentUserId={user?.id}
                      isAdmin={isAdmin}
                      onDelete={handleDeleteFeedback}
                    />
                  ))}
                </div>
              )}
            </div>
          </motion.div>

          {/* Sidebar */}
          <div className="space-y-4">
            {!isOwner && <FeedbackForm trackId={trackId} />}
            {!isOwner && (
              <button
                onClick={handleMessageArtist}
                className="w-full flex items-center justify-center gap-2 h-10 rounded-xl border border-border bg-card text-sm font-medium text-foreground hover:bg-accent transition-colors"
              >
                <Send className="w-4 h-4 text-primary" />
                Message Artist
              </button>
            )}
            {isOwner && (
              <div className="rounded-xl border border-border bg-card p-4 space-y-3">
                <div className="text-center">
                  <p className="text-sm font-medium text-foreground">This is your track</p>
                  <p className="text-xs text-muted-foreground mt-0.5">You can't review your own work.</p>
                </div>
                <button
                  onClick={handleDeleteTrack}
                  className={`w-full flex items-center justify-center gap-2 h-9 rounded-lg text-xs font-medium transition-colors border ${
                    confirmDeleteTrack
                      ? "border-destructive bg-destructive text-white"
                      : "border-border text-destructive hover:bg-destructive/5"
                  }`}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  {confirmDeleteTrack ? "Tap again to confirm delete" : "Delete Track"}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}