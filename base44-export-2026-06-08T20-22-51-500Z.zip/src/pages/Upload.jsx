const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";

import { useAuth } from "@/lib/AuthContext";
import { useNavigate } from "react-router-dom";
import { Upload as UploadIcon, Music, Image, Loader2, CheckCircle } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { motion } from "framer-motion";

export default function Upload() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [uploading, setUploading] = useState(false);
  const [audioFile, setAudioFile] = useState(null);
  const [coverFile, setCoverFile] = useState(null);
  const [form, setForm] = useState({
    title: "",
    description: "",
    genre: "",
    feedback_request: "",
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!audioFile) return;
    setUploading(true);

    const { file_url: audio_url } = await db.integrations.Core.UploadFile({ file: audioFile });

    let cover_url = "";
    if (coverFile) {
      const res = await db.integrations.Core.UploadFile({ file: coverFile });
      cover_url = res.file_url;
    }

    const artistName = user?.username ? `@${user.username}` : (user?.display_name || user?.full_name || "Unknown Artist");

    await db.entities.Track.create({
      ...form,
      audio_url,
      cover_url,
      artist_name: artistName,
    });

    navigate("/");
  };

  const update = (field, value) => setForm((prev) => ({ ...prev, [field]: value }));

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-xl mx-auto px-4 sm:px-6 py-10">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-7"
        >
          <h1 className="text-2xl font-heading font-bold">Upload a Track</h1>
          <p className="text-muted-foreground text-sm mt-1">Share your music and get community feedback.</p>
        </motion.div>

        <motion.form
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.08 }}
          onSubmit={handleSubmit}
          className="space-y-5"
        >
          {/* Audio Upload */}
          <div className="space-y-1.5">
            <Label className="text-sm font-medium">Audio File *</Label>
            <label className="flex flex-col items-center justify-center gap-2.5 p-7 rounded-xl border-2 border-dashed border-border bg-white hover:border-primary/40 hover:bg-muted/30 transition-all cursor-pointer">
              {audioFile ? (
                <div className="flex items-center gap-2 text-primary">
                  <CheckCircle className="w-5 h-5" />
                  <span className="text-sm font-medium truncate max-w-[220px]">{audioFile.name}</span>
                </div>
              ) : (
                <>
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                    <Music className="w-5 h-5 text-primary" />
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-medium text-foreground">Drop your audio file here</p>
                    <p className="text-xs text-muted-foreground mt-0.5">MP3, WAV, OGG, M4A</p>
                  </div>
                </>
              )}
              <input
                type="file"
                accept="audio/*"
                className="hidden"
                onChange={(e) => setAudioFile(e.target.files?.[0])}
              />
            </label>
          </div>

          {/* Cover Image */}
          <div className="space-y-1.5">
            <Label className="text-sm font-medium">Cover Image <span className="text-muted-foreground font-normal">(optional)</span></Label>
            <label className="flex items-center justify-center gap-2.5 p-4 rounded-xl border border-border bg-white hover:border-primary/40 hover:bg-muted/20 transition-all cursor-pointer">
              {coverFile ? (
                <div className="flex items-center gap-2 text-primary">
                  <CheckCircle className="w-4 h-4" />
                  <span className="text-sm truncate max-w-[220px]">{coverFile.name}</span>
                </div>
              ) : (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Image className="w-4 h-4" />
                  <span className="text-sm">Upload cover art</span>
                </div>
              )}
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => setCoverFile(e.target.files?.[0])}
              />
            </label>
          </div>

          {/* Fields */}
          <div className="space-y-1.5">
            <Label className="text-sm font-medium">Title *</Label>
            <Input
              value={form.title}
              onChange={(e) => update("title", e.target.value)}
              placeholder="Track title"
              className="bg-white border-border h-10 text-sm"
              required
            />
          </div>

          <div className="space-y-1.5">
            <Label className="text-sm font-medium">Genre</Label>
            <Select value={form.genre} onValueChange={(v) => update("genre", v)}>
              <SelectTrigger className="bg-white border-border h-10 text-sm">
                <SelectValue placeholder="Select a genre" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="hip_hop">Hip Hop</SelectItem>
                <SelectItem value="rnb">R&B</SelectItem>
                <SelectItem value="pop">Pop</SelectItem>
                <SelectItem value="rock">Rock</SelectItem>
                <SelectItem value="electronic">Electronic</SelectItem>
                <SelectItem value="jazz">Jazz</SelectItem>
                <SelectItem value="indie">Indie</SelectItem>
                <SelectItem value="latin">Latin</SelectItem>
                <SelectItem value="country">Country</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <Label className="text-sm font-medium">Description</Label>
            <Textarea
              value={form.description}
              onChange={(e) => update("description", e.target.value)}
              placeholder="Tell us about this track..."
              className="min-h-[72px] bg-white border-border resize-none text-sm"
            />
          </div>

          <div className="space-y-1.5">
            <Label className="text-sm font-medium">What feedback are you looking for?</Label>
            <Textarea
              value={form.feedback_request}
              onChange={(e) => update("feedback_request", e.target.value)}
              placeholder="e.g. How's the mix? Does the hook land?"
              className="min-h-[72px] bg-white border-border resize-none text-sm"
            />
          </div>

          <button
            type="submit"
            disabled={uploading || !audioFile || !form.title}
            className="w-full h-11 rounded-xl btn-primary text-white font-semibold text-sm flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            {uploading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Uploading...
              </>
            ) : (
              <>
                <UploadIcon className="w-4 h-4" />
                Upload Track
              </>
            )}
          </button>
        </motion.form>
      </div>
    </div>
  );
}