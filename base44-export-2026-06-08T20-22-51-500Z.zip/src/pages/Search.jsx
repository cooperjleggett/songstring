const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";
import { useNavigate } from "react-router-dom";

import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search as SearchIcon, AtSign, MessageSquare, Music, BadgeCheck, User } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useQuery } from "@tanstack/react-query";

export default function Search() {
  const [query, setQuery] = useState("");
  const navigate = useNavigate();

  const { data: users = [], isFetching } = useQuery({
    queryKey: ["user-search", query],
    queryFn: async () => {
      if (query.trim().length < 2) return [];
      const clean = query.replace(/^@/, "").toLowerCase().trim();
      const all = await db.entities.User.list();
      return all.filter(
        (u) =>
          u.username?.toLowerCase().includes(clean) ||
          u.full_name?.toLowerCase().includes(clean)
      );
    },
    enabled: query.trim().length >= 2,
    placeholderData: [],
  });

  const handleMessage = async (e, targetUser) => {
    e.stopPropagation();
    navigate(`/messages?userId=${targetUser.id}&userName=${encodeURIComponent(targetUser.username || targetUser.full_name)}`);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-10">
      <div className="mb-8">
        <h1 className="text-2xl font-heading font-bold text-foreground mb-1">Find Artists</h1>
        <p className="text-sm text-muted-foreground">Search by @username or display name</p>
      </div>

      {/* Search input */}
      <div className="relative mb-8">
        <AtSign className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          autoFocus
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search @username or name..."
          className="pl-10 h-12 text-base border-border bg-white"
        />
        {isFetching && (
          <div className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 border-2 border-muted border-t-primary rounded-full animate-spin" />
        )}
      </div>

      {/* Results */}
      <AnimatePresence mode="popLayout">
        {query.trim().length >= 2 && !isFetching && users.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="text-center py-16 text-muted-foreground"
          >
            <SearchIcon className="w-8 h-8 mx-auto mb-3 opacity-30" />
            <p className="text-sm">No users found for "<span className="font-medium text-foreground">{query}</span>"</p>
          </motion.div>
        )}

        {users.map((u, i) => (
          <motion.div
            key={u.id}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ delay: i * 0.04 }}
            onClick={() => navigate(`/profile?id=${u.id}`)}
            className="flex items-center gap-4 p-4 rounded-xl border border-border bg-white hover:shadow-sm hover:border-primary/30 cursor-pointer transition-all mb-3"
          >
            {/* Avatar */}
            <div className="w-12 h-12 rounded-full bg-primary/10 flex-shrink-0 overflow-hidden flex items-center justify-center">
              {u.avatar_url ? (
                <img src={u.avatar_url} alt={u.full_name} className="w-full h-full object-cover" />
              ) : (
                <span className="text-lg font-bold text-primary">
                  {(u.username || u.full_name || "U")[0].toUpperCase()}
                </span>
              )}
            </div>

            {/* Info */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                {u.username ? (
                  <span className="font-heading font-bold text-foreground">@{u.username}</span>
                ) : (
                  <span className="font-heading font-bold text-foreground">{u.full_name}</span>
                )}
                {u.verified && <BadgeCheck className="w-4 h-4 text-primary flex-shrink-0" />}
              </div>
              {u.username && u.full_name && (
                <p className="text-sm text-muted-foreground truncate">{u.full_name}</p>
              )}
              {u.bio && (
                <p className="text-xs text-muted-foreground truncate mt-0.5">{u.bio}</p>
              )}
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2 flex-shrink-0">
              <Button
                size="sm"
                variant="outline"
                className="gap-1.5 text-xs"
                onClick={(e) => handleMessage(e, u)}
              >
                <MessageSquare className="w-3.5 h-3.5" />
                Message
              </Button>
              <Button
                size="sm"
                variant="ghost"
                className="gap-1.5 text-xs text-muted-foreground"
                onClick={(e) => { e.stopPropagation(); navigate(`/profile?id=${u.id}`); }}
              >
                <User className="w-3.5 h-3.5" />
                Profile
              </Button>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>

      {/* Empty state before typing */}
      {query.trim().length < 2 && (
        <div className="text-center py-16 text-muted-foreground">
          <SearchIcon className="w-10 h-10 mx-auto mb-3 opacity-20" />
          <p className="text-sm">Type at least 2 characters to search</p>
        </div>
      )}
    </div>
  );
}