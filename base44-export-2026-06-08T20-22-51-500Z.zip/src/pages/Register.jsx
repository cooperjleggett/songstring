const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from "react";
import { Link } from "react-router-dom";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Mail, Lock, Loader2, AtSign } from "lucide-react";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import SongstringLogo from "@/components/SongstringLogo";
import GoogleIcon from "@/components/GoogleIcon";

const AuthPanel = () => (
  <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden bg-foreground flex-col justify-between p-12">
    <div
      className="absolute inset-0 bg-cover bg-center opacity-20"
      style={{ backgroundImage: "url('https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=1200&q=80')" }}
    />
    <div className="relative z-10 flex items-center gap-2.5">
      <SongstringLogo size={36} />
      <span className="text-xl font-heading font-bold text-white">Songstring</span>
    </div>
    <div className="relative z-10 space-y-3">
      <p className="text-white text-2xl font-heading font-semibold leading-snug">
        "The feedback I got on Songstring completely changed how I approach mixing."
      </p>
      <p className="text-white/50 text-sm">— Independent artist, community member</p>
    </div>
  </div>
);

export default function Register() {
  const [step, setStep] = useState("form"); // "form" | "otp"
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [otpCode, setOtpCode] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleUsernameChange = (val) => {
    setUsername(val.toLowerCase().replace(/[^a-z0-9_]/g, ""));
    setError("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (!username || username.length < 3) {
      setError("Username must be at least 3 characters.");
      return;
    }
    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    if (password.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }

    setLoading(true);
    try {
      await db.auth.register({ email, password });
      setStep("otp");
    } catch (err) {
      setError(err.message || "Registration failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleVerify = async () => {
    setError("");
    setLoading(true);
    try {
      const result = await db.auth.verifyOtp({ email, otpCode });
      if (result?.access_token) {
        db.auth.setToken(result.access_token);
        // Save username after token is set
        try {
          await db.auth.updateMe({ username, display_name: username });
        } catch {
          // Non-fatal — user can set it later
        }
      }
      window.location.href = "/";
    } catch (err) {
      setError(err.message || "Invalid verification code. Please try again.");
      setLoading(false);
    }
  };

  const handleResend = async () => {
    setError("");
    try {
      await db.auth.resendOtp(email);
    } catch (err) {
      setError(err.message || "Failed to resend code");
    }
  };

  const handleGoogle = () => {
    db.auth.loginWithProvider("google", "/");
  };

  if (step === "otp") {
    return (
      <div className="min-h-screen flex bg-background">
        <AuthPanel />
        <div className="flex-1 flex flex-col items-center justify-center px-6 py-12">
          <div className="flex lg:hidden items-center gap-2 mb-10">
            <SongstringLogo size={36} />
            <span className="text-xl font-heading font-bold text-foreground">Songstring</span>
          </div>
          <div className="w-full max-w-sm">
            <div className="mb-8 text-center">
              <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Mail className="w-6 h-6 text-primary" />
              </div>
              <h1 className="text-2xl font-heading font-bold text-foreground">Check your email</h1>
              <p className="text-muted-foreground text-sm mt-2">
                We sent a 6-digit code to <span className="font-medium text-foreground">{email}</span>
              </p>
            </div>

            {error && (
              <div className="mb-5 p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-destructive text-sm">
                {error}
              </div>
            )}

            <div className="flex justify-center mb-6">
              <InputOTP maxLength={6} value={otpCode} onChange={setOtpCode} autoFocus autoComplete="one-time-code">
                <InputOTPGroup>
                  <InputOTPSlot index={0} />
                  <InputOTPSlot index={1} />
                  <InputOTPSlot index={2} />
                  <InputOTPSlot index={3} />
                  <InputOTPSlot index={4} />
                  <InputOTPSlot index={5} />
                </InputOTPGroup>
              </InputOTP>
            </div>

            <Button
              className="w-full h-11 font-medium"
              onClick={handleVerify}
              disabled={loading || otpCode.length < 6}
            >
              {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Verifying...</> : "Verify email"}
            </Button>

            <p className="text-center text-sm text-muted-foreground mt-5">
              Didn't receive the code?{" "}
              <button onClick={handleResend} className="text-primary font-medium hover:underline">
                Resend
              </button>
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex bg-background">
      <AuthPanel />
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-12 overflow-y-auto">
        <div className="flex lg:hidden items-center gap-2 mb-10">
          <SongstringLogo size={36} />
          <span className="text-xl font-heading font-bold text-foreground">Songstring</span>
        </div>

        <div className="w-full max-w-sm">
          <div className="mb-8">
            <h1 className="text-2xl font-heading font-bold text-foreground">Create your account</h1>
            <p className="text-muted-foreground text-sm mt-1">Join the community of independent artists</p>
          </div>

          <Button
            variant="outline"
            className="w-full h-11 text-sm font-medium border-border mb-6"
            onClick={handleGoogle}
          >
            <GoogleIcon className="w-4 h-4 mr-2" />
            Continue with Google
          </Button>

          <div className="relative mb-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-border" />
            </div>
            <div className="relative flex justify-center text-xs">
              <span className="bg-background px-3 text-muted-foreground">or continue with email</span>
            </div>
          </div>

          {error && (
            <div className="mb-5 p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-destructive text-sm">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="username" className="text-sm font-medium text-foreground">
                Username <span className="text-destructive">*</span>
              </Label>
              <div className="relative">
                <AtSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="username"
                  type="text"
                  placeholder="yourhandle"
                  value={username}
                  onChange={(e) => handleUsernameChange(e.target.value)}
                  className="pl-10 h-11 bg-background border-border text-foreground"
                  required
                />
              </div>
              {username.length > 0 && username.length < 3 && (
                <p className="text-xs text-destructive">At least 3 characters required</p>
              )}
              {username.length >= 3 && (
                <p className="text-xs text-muted-foreground">Your handle: <span className="text-foreground font-medium">@{username}</span></p>
              )}
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="email" className="text-sm font-medium text-foreground">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  autoComplete="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10 h-11 bg-background border-border text-foreground"
                  required
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="password" className="text-sm font-medium text-foreground">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="password"
                  type="password"
                  autoComplete="new-password"
                  placeholder="At least 8 characters"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10 h-11 bg-background border-border text-foreground"
                  required
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="confirm" className="text-sm font-medium text-foreground">Confirm Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="confirm"
                  type="password"
                  autoComplete="new-password"
                  placeholder="••••••••"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="pl-10 h-11 bg-background border-border text-foreground"
                  required
                />
              </div>
            </div>

            <Button type="submit" className="w-full h-11 font-medium mt-1" disabled={loading}>
              {loading ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Creating account...</>
              ) : (
                "Create account"
              )}
            </Button>
          </form>

          <p className="text-center text-sm text-muted-foreground mt-6">
            Already have an account?{" "}
            <Link to="/login" className="text-primary font-medium hover:underline">
              Sign in
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}