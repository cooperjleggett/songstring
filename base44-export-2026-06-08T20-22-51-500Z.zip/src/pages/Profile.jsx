const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from "react";

import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/AuthContext";
import { Link } from "react-router-dom";
import { ArrowLeft, Music, Star, MessageSquare, Pencil, Settings, ThumbsUp, BadgeCheck, Shield, Award } from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import TrackCard from "@/components/tracks/TrackCard";
import FeedbackItem from "@/components/feedback/FeedbackItem";
import EditProfileModal from "@/components/profile/EditProfileModal";
import AccountSettingsModal from "@/components/profile/AccountSettingsModal";
import VerificationRequestModal from "@/components/profile/VerificationRequestModal";

const TABS = ["Tracks", "Reviews Given"];

export default function Profile() {
  const urlParams = new URLSearchParams(window.location.search);
  const userId = urlParams.get("id");
  const { user: currentUser } = useAuth();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("Tracks");
  const [showEdit, setShowEdit] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showVerifyRequest, setShowVerifyRequest] = useState(false);
  const [togglingVerify, setTogglingVerify] = useState(false);

  const targetId = userId || currentUser?.id;
  const isOwn = !userId || userId === currentUser?.id;
  const isAdmin = currentUser?.role === "admin";

  const { data: profileUser, refetch: refetchUser } = useQuery({
    queryKey: ["profileUser", targetId],
    queryFn: async () => {
      if (isOwn) return currentUser;
      const users = await db.entities.User.filter({ id: targetId });
      return users[0];
    },
    enabled: !!targetId,
  });

  const { data: tracks = [], isLoading } = useQuery({
    queryKey: ["profileTracks", targetId],
    queryFn: () => db.entities.Track.filter({ created_by_id: targetId }, "-created_date"),
    enabled: !!targetId,
  });

  const { data: feedbacksGiven = [], isLoading: loadingFeedback } = useQuery({
    queryKey: ["profileFeedbacksGiven", targetId],
    queryFn: () => db.entities.Feedback.filter({ created_by_id: targetId }, "-created_date"),
    enabled: !!targetId,
  });

  const totalFeedbackReceived = tracks.reduce((sum, t) => sum + (t.feedback_count || 0), 0);
  const ratedTracks = tracks.filter(t => t.avg_rating > 0);
  const avgRating = ratedTracks.length > 0
    ? ratedTracks.reduce((sum, t) => sum + t.avg_rating, 0) / ratedTracks.length
    : 0;

  const name = profileUser?.display_name || profileUser?.full_name || profileUser?.email?.split("@")[0] || "Artist";
  const username = profileUser?.username;
  const initials = name.split(" ").map(w => w[0]).join("").toUpperCase().slice(0, 2);
  const isVerified = profileUser?.verified;

  const handleSaved = () => {
    refetchUser();
    queryClient.invalidateQueries({ queryKey: ["profileUser", targetId] });
  };

  const handleToggleVerify = async () => {
    setTogglingVerify(true);
    await db.entities.User.update(targetId, { verified: !isVerified });
    refetchUser();
    queryClient.invalidateQueries({ queryKey: ["profileUser", targetId] });
    setTogglingVerify(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
        <Link to="/" className="inline-flex items-center gap-1.5 text-muted-foreground hover:text-foreground mb-6 transition-colors text-sm">
          <ArrowLeft className="w-4 h-4" />
          Back
        </Link>

        {/* Profile header */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-start gap-5 mb-6"
        >
          <div className="w-20 h-20 rounded-full bg-primary/10 border-2 border-primary/20 flex items-center justify-center overflow-hidden flex-shrink-0">
            {profileUser?.avatar_url ? (
              <img src={profileUser.avatar_url} alt={name} className="w-full h-full object-cover" />
            ) : (
              <span className="text-2xl font-heading font-bold text-primary">{initials}</span>
            )}
          </div>
          <div className="flex-1 min-w-0 pt-1">
            {username ? (
              <div className="flex items-center gap-2 flex-wrap mb-0.5">
                <p className="text-lg font-heading font-bold text-foreground">@{username}</p>
                {isVerified && (
                  <BadgeCheck className="w-5 h-5 text-primary flex-shrink-0" title="Verified artist" />
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2 mb-0.5">
                <h1 className="text-2xl font-heading font-bold text-foreground">{name}</h1>
                {isVerified && (
                  <BadgeCheck className="w-5 h-5 text-primary flex-shrink-0" title="Verified artist" />
                )}
              </div>
            )}
            {username && name && name !== username && (
              <p className="text-sm text-muted-foreground">{name}</p>
            )}
            {isOwn && !username && (
              <button
                onClick={() => setShowEdit(true)}
                className="text-xs text-primary hover:underline mt-0.5"
              >
                + Set a @username
              </button>
            )}
            {isOwn && (
              <p className="text-xs text-muted-foreground mt-0.5">{profileUser?.email}</p>
            )}
            {profileUser?.bio && (
              <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{profileUser.bio}</p>
            )}
          </div>
          <div className="flex flex-col gap-2 pt-1 items-end shrink-0">
            {isOwn && (
              <div className="flex flex-wrap gap-2 justify-end">
                <Button size="sm" variant="outline" onClick={() => setShowEdit(true)} className="gap-1.5">
                  <Pencil className="w-3.5 h-3.5" />
                  Edit
                </Button>
                <Button size="sm" variant="outline" onClick={() => setShowSettings(true)} className="gap-1.5">
                  <Settings className="w-3.5 h-3.5" />
                  Settings
                </Button>
                {!isVerified && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setShowVerifyRequest(true)}
                    className="gap-1.5 border-primary/30 text-primary hover:bg-primary/5"
                  >
                    <Award className="w-3.5 h-3.5" />
                    {profileUser?.verification_requested ? "Verification Pending" : "Request Verification"}
                  </Button>
                )}
              </div>
            )}
            {/* Admin-only: verify toggle */}
            {isAdmin && !isOwn && (
              <div className="flex flex-col gap-2 items-end">
                {profileUser?.verification_requested && !isVerified && (
                  <span className="text-xs font-medium text-amber-600 bg-amber-50 border border-amber-200 px-2 py-1 rounded-lg">
                    Verification requested
                  </span>
                )}
                <button
                  onClick={handleToggleVerify}
                  disabled={togglingVerify}
                  title={isVerified ? "Remove verification" : "Grant verification badge"}
                  className={`flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border font-medium transition-colors ${
                    isVerified
                      ? "border-primary/30 bg-primary/5 text-primary hover:bg-destructive/10 hover:text-destructive hover:border-destructive/30"
                      : "border-border text-muted-foreground hover:border-primary hover:text-primary"
                  }`}
                >
                  <Shield className="w-3 h-3" />
                  {isVerified ? "Verified · Remove" : "Grant Verification"}
                </button>
              </div>
            )}
          </div>
        </motion.div>

        {/* Stats row */}
        <div className="grid grid-cols-3 gap-3 mb-8">
          {[
            { label: "Tracks", value: tracks.length, icon: Music },
            { label: "Reviews received", value: totalFeedbackReceived, icon: MessageSquare },
            { label: "Avg rating", value: avgRating ? avgRating.toFixed(1) : "—", icon: Star },
          ].map((s, i) => {
            const Icon = s.icon;
            return (
              <motion.div
                key={s.label}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.06 }}
                className="rounded-xl border border-border bg-white p-4 text-center"
              >
                <Icon className="w-4 h-4 text-primary mx-auto mb-1.5" />
                <p className="text-xl font-heading font-bold text-foreground">{s.value}</p>
                <p className="text-xs text-muted-foreground">{s.label}</p>
              </motion.div>
            );
          })}
        </div>

        {/* Tabs */}
        <div className="flex gap-1 border-b border-border mb-6">
          {(isOwn ? TABS : ["Tracks"]).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 text-sm font-medium transition-colors border-b-2 -mb-px ${
                activeTab === tab
                  ? "border-primary text-primary"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              {tab === "Reviews Given" && <ThumbsUp className="w-3.5 h-3.5 inline mr-1.5" />}
              {tab === "Tracks" && <Music className="w-3.5 h-3.5 inline mr-1.5" />}
              {tab}
            </button>
          ))}
        </div>

        {/* Tab content */}
        {activeTab === "Tracks" && (
          <div>
            {isLoading ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="rounded-2xl bg-muted animate-pulse aspect-square" />
                ))}
              </div>
            ) : tracks.length === 0 ? (
              <div className="text-center py-12 rounded-xl border border-dashed border-border">
                <Music className="w-8 h-8 text-muted-foreground/30 mx-auto mb-2" />
                <p className="text-muted-foreground text-sm">No tracks uploaded yet.</p>
                {isOwn && (
                  <Button asChild size="sm" className="mt-4">
                    <Link to="/upload">Upload your first track</Link>
                  </Button>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                {tracks.map((track, i) => (
                  <TrackCard key={track.id} track={track} index={i} />
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === "Reviews Given" && (
          <div className="space-y-3">
            {loadingFeedback ? (
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="rounded-xl bg-muted animate-pulse h-24" />
                ))}
              </div>
            ) : feedbacksGiven.length === 0 ? (
              <div className="text-center py-12 rounded-xl border border-dashed border-border">
                <ThumbsUp className="w-8 h-8 text-muted-foreground/30 mx-auto mb-2" />
                <p className="text-muted-foreground text-sm">No reviews given yet.</p>
              </div>
            ) : (
              feedbacksGiven.map((fb, i) => (
                <FeedbackItem key={fb.id} feedback={fb} index={i} />
              ))
            )}
          </div>
        )}
      </div>

      {showEdit && (
        <EditProfileModal
          open={showEdit}
          onClose={() => setShowEdit(false)}
          user={profileUser}
          onSaved={handleSaved}
        />
      )}
      {showSettings && (
        <AccountSettingsModal
          open={showSettings}
          onClose={() => setShowSettings(false)}
          user={profileUser}
          onSaved={handleSaved}
        />
      )}
      {showVerifyRequest && (
        <VerificationRequestModal
          open={showVerifyRequest}
          onClose={() => setShowVerifyRequest(false)}
          user={profileUser}
          onSaved={handleSaved}
        />
      )}
    </div>
  );
}